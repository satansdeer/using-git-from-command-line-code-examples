More changes to the README.md file
