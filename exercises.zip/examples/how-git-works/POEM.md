Octopus and cat, one animal from two.
This peculiar creature will teach Git to you.
An octopus and cat, merged into one,
This quirky beast makes git lessons fun.
