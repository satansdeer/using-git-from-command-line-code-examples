# README

You can apply stashes on any branch
