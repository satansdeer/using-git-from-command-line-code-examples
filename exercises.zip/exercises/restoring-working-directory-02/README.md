New changes to the README.md file
