Octopus and cat, one animal from two.
his peculiar creature will teach Git to you.
