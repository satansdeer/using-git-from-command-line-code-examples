Initial draft
