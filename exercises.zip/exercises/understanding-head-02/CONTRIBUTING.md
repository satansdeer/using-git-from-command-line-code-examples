This is a CONTRIBUTING.md file
