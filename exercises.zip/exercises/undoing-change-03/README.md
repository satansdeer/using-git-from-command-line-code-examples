Unwanted changes to the README.md file
Changes that we want to preserve
