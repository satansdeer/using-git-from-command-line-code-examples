Octopus and cat, one animal from two.
This peculiar creature will teach Git to you.
